
<html>
<head>
    <title>Exemplo de Integração com gov.br em PHP</title>
</head>
<body>
    <h1>Página de logout da minha aplicação</h1>
    <p>Logout realizado com sucesso!</p>
</body>




