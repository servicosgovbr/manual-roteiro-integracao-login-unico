package oauth.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

public class SelosDto implements Serializable{
	private static final long serialVersionUID = 1L;

	@JsonInclude(Include.NON_EMPTY) public Integer id;
	@JsonInclude(Include.NON_EMPTY) public Integer nivel;
	@JsonInclude(Include.NON_EMPTY) public String descricao;
	@JsonInclude(Include.NON_EMPTY) public String escopoSelo;
	
	public SelosDto() {}

	public SelosDto(Integer id, Integer nivel, String descricao, String escopoSelo) {
		super();
		this.id = id;
		this.nivel = nivel;
		this.descricao = descricao;
		this.escopoSelo = escopoSelo;
	}
}
