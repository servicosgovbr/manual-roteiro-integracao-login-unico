package oauth;

import java.io.IOException;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.RequestBody;

import oauth.dto.EmpresaDto;
import oauth.dto.EmpresasVinculadasDto;
import oauth.dto.SelosDto;
import oauth.dto.TokensDto;
import oauth.env.EnvVars;
import spark.utils.IOUtils;

public class Service {

    public Service() {}

    public TokensDto getTokens(String clientId, String code, String codeVerifier) throws IOException {
        OkHttpClient client = new OkHttpClient();
				
		RequestBody body = RequestBody.create(MediaType.parse("application/json; charset=utf-8"), "{}");
		com.squareup.okhttp.Request request = new com.squareup.okhttp.Request.Builder()
                .url(EnvVars.getTokenServiceUrl() + "?grant_type=authorization_code&client_id=" + clientId +"&code=" + code +"&code_verifier=" + codeVerifier + "&redirect_uri=" + EnvVars.getRedirectUri())
				.post(body)
				.header("Authorization", "Basic " + EnvVars.getCredentials())
				.build();

		com.squareup.okhttp.Response response = client.newCall(request).execute();

		if (response.code() != 200) {
			return new TokensDto("FAIL", response.message());
		}

		//String json = "{   \"access_token\": \"eyJraWQiOiJyc2ExIiwiYWxnIjoiUlMyNTYifQ.eyJzdWIiOiI2OTE5NDEwNjEzNCIsImF1ZCI6Imdvdi5iclwvY2hlY2tpbmdvdiIsInNjb3BlIjpbImFkZHJlc3MiLCJlbWFpbCIsIm9wZW5pZCIsInBob25lIiwicHJvZmlsZSIsInJmYl9jb21wbGV0byIsInJmYl9lbXByZXNhX2NvbXBsZXRvIl0sImFtciI6InBhc3N3ZCIsImlzcyI6Imh0dHBzOlwvXC9zc28uYWNlc3NvLmdvdi5iclwvIiwiZXhwIjoxNTY4MjIxNzYyLCJpYXQiOjE1NjgyMTgxNjIsImp0aSI6IjM4MDA5MjA5LTE2YzMtNGJkYy1iY2UxLTU3ZWQxZWY2ZTg4ZCJ9.P2i5h1ZPdwE9tLVCE0A3gZ-HLFOHIuJDaDSsVM9kNQ9e8P2kjjpbJiO3hRKVlNnj2KZ7sI4s8O7oJIlkcVOX4WIoq1Vr_-_rspSk2TfOjPjR4Olxs4L9RN6c3KWO-SYjmKN4T4RTZ1mf9crqGIFxQuq5zcxEbtuMNL7ojiNb-W_FfF-qLPh5Mn3dh_u83Rk5Wp_O2Hk1JCsG6anfkZmLK_6o8TJeeLUgVYcOYtkN02q9MTiOJ6606NHappebnm3rHHL9NT5qpr1ei0Yx7wKR-5KgLJvTKN4biYlVvZtnzuoBCntzFLsQZUsPfHWPQqk6eq9pycOj0TsARsKhXewKzg\",   \"token_type\": \"Bearer\",   \"expires_in\": 3599,   \"scope\": \"address phone openid rfb_completo profile rfb_empresa_completo email\",   \"id_token\": \"eyJraWQiOiJyc2ExIiwiYWxnIjoiUlMyNTYifQ.eyJzdWIiOiI2OTE5NDEwNjEzNCIsImVtYWlsX3ZlcmlmaWVkIjoidHJ1ZSIsImFtciI6InBhc3N3ZCIsInByb2ZpbGUiOiJodHRwczpcL1wvYWNlc3NvLmdvdi5iciIsImtpZCI6InJzYTEiLCJpc3MiOiJodHRwczpcL1wvc3NvLmFjZXNzby5nb3YuYnJcLyIsInBob25lX251bWJlcl92ZXJpZmllZCI6InRydWUiLCJub25jZSI6IjEyMzQ1XCIiLCJwaWN0dXJlIjoiaHR0cHM6XC9cL3Nzby5hY2Vzc28uZ292LmJyXC91c2VyaW5mb1wvcGljdHVyZSIsImF1ZCI6Imdvdi5iclwvY2hlY2tpbmdvdiIsImF1dGhfdGltZSI6MTU2ODIxODEzOSwic2NvcGUiOlsiYWRkcmVzcyIsImVtYWlsIiwib3BlbmlkIiwicGhvbmUiLCJwcm9maWxlIiwicmZiX2NvbXBsZXRvIiwicmZiX2VtcHJlc2FfY29tcGxldG8iXSwibmFtZSI6Ik1hcmN1cyBWaW7DrWNpdXMgVCBkZSBBbG1laWRhIiwicGhvbmVfbnVtYmVyIjoiNjE5ODExNjE4MDkiLCJleHAiOjE1NjgyMTg3NjIsImlhdCI6MTU2ODIxODE2MiwianRpIjoiNWEyOGZiN2MtNDgwZi00ZDMwLTkzNWYtNzcyZTY4ZDQ4NWI1IiwiZW1haWwiOiJ2dG1hcmN1c0BnbWFpbC5jb20ifQ.EafQ5b9RidcpTMRNRs_jSMoBW8VMJAa4fLt0ScvvPVcxIHoPX5Mceog2LWhCQWVlz5bfkExL_ZJTaXgvvkihRDzW4nYTUxJzZddSXH69Uu3ugFdtA11g4PHzGOOxNulfrqUh03vt5ZzomzwKhrZlQJSFOehvVSgnPZ8EPMiCswAmBcZYQYC4kbu5lbhpMvGpWWorhQ1M-zWtnw3lWAy-BOljPoaVHC2_l2VRuZV6J_-3jnmKe0T_1CKAQly-Me5Nhy_yXcV5bbEUvfPhzOnaHaL3AF7E9ZLfdEE0U6gae7UBCuoqP_HMJFaaBP5q9s37LokTNJopz4At4wIbynl3lQ\" }";
		String json = response.body().string();
		ObjectMapper mapper = new ObjectMapper();
		TokensDto tokensDto = mapper.readValue(json, TokensDto.class);
		tokensDto.setStatus("SUCCESS");

		return tokensDto;
	}

	public List<SelosDto> getConfiabilidade(String accessToken) throws Exception {
		ObjectMapper mapper = new ObjectMapper();
		OkHttpClient client = new OkHttpClient();
		com.squareup.okhttp.Request request = new com.squareup.okhttp.Request.Builder()
				.url(EnvVars.getServiceUrl() + "/api/info/usuario/selo")
				.get()
				.header("Authorization", "Bearer " + accessToken)
				.build();

		String responseBodyString = null;
		try {
			responseBodyString = client.newCall(request).execute().body().string();
			return Arrays.asList(mapper.readValue(responseBodyString, SelosDto[].class));
		} catch (Exception e) {
			return null;
		}
	}

	public EmpresasVinculadasDto getEmpresasVinculadas(String cpf, String accessToken) throws Exception {
		ObjectMapper mapper = new ObjectMapper();
		OkHttpClient client = new OkHttpClient();
		com.squareup.okhttp.Request request = new com.squareup.okhttp.Request.Builder()
				.url(EnvVars.getServiceUrl() + "/empresas/v1/representantes/" + cpf +"/empresas")
				.get()
				.header("Authorization", "Bearer " + accessToken)
				.build();

		String responseBodyString = null;
		try {
			responseBodyString = client.newCall(request).execute().body().string();
			return mapper.readValue(responseBodyString, EmpresasVinculadasDto.class);
		} catch (Exception e) {
			return null;
		}
	}
	
	public EmpresaDto getEmpresaDetalhamento(String cpf, String cnpj, String accessToken) throws Exception {
		ObjectMapper mapper = new ObjectMapper();
		OkHttpClient client = new OkHttpClient();
		com.squareup.okhttp.Request request = new com.squareup.okhttp.Request.Builder()
				.url(EnvVars.getServiceUrl() + "/empresas/v1/representantes/" + cpf +"/empresas/" + cnpj)
				.get()
				.header("Authorization", "Bearer " + accessToken)
				.build();

		String responseBodyString = null;
		try {
			responseBodyString = client.newCall(request).execute().body().string();
			return mapper.readValue(responseBodyString, EmpresaDto.class);
		} catch (Exception e) {
			return null;
		}
	}
	
	public String getPhoto(String picuteUrl, String accessToken) throws IOException {
		
		if (picuteUrl == null) {
			return null;
		}

		OkHttpClient client = new OkHttpClient();
		com.squareup.okhttp.Request request = new com.squareup.okhttp.Request.Builder()
				.url(picuteUrl)
				.get()
				.header("Authorization", "Bearer " + accessToken)
				.build();

		com.squareup.okhttp.Response response = client.newCall(request).execute();

		if (response.code() != 200) {
			return null;
		}

		return Base64.getEncoder().encodeToString(IOUtils.toByteArray(response.body().byteStream()));
		
	}
}
