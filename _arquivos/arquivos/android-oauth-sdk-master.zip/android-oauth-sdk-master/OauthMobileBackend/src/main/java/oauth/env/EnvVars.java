package oauth.env;

public class EnvVars {
	
	private static final String ERR_NEW_UNSUPPORTED = "oauth.env.EnvVars.new.unsupported";

	private EnvVars() {
		throw new UnsupportedOperationException(ERR_NEW_UNSUPPORTED);
	}
	public static String getIssuer() {
		return System.getenv("ISSUER");
	}
	public static String getJwkRsaWebKey() {
		return System.getenv("JWK_RSA_WEB_KEY");
	}
	public static String getClientId() {
		return System.getenv("CLIENT_ID");
	}
	public static String getTokenServiceUrl() {
		return System.getenv("TOKEN_SERVICE_URL");
	}
	public static String getRedirectUri(){
		return System.getenv("REDIRECT_URI");
	}
	public static String getCredentials(){
		return System.getenv("CREDENTIALS");
	}
	public static String getJwkServiceUrl(){
		return System.getenv("JWK_SERVICE_URL");
	}
	public static String getServiceUrl(){
		return System.getenv("SERVICE_URL");
	}
}