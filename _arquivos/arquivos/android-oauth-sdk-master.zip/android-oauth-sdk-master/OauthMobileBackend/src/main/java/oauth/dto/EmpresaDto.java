package oauth.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

public class EmpresaDto implements Serializable{
	private static final long serialVersionUID = 1L;

	@JsonInclude(Include.NON_EMPTY) public String cnpj;
	@JsonInclude(Include.NON_EMPTY) public String nomeFantasia;
	@JsonInclude(Include.NON_EMPTY) public String atuacao;
	
	public EmpresaDto() {}

	public EmpresaDto(String cnpj, String nomeFantasia, String atuacao) {
		super();
		this.cnpj = cnpj;
		this.nomeFantasia = nomeFantasia;
		this.atuacao = atuacao;
	}
}
