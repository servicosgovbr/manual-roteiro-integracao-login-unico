package oauth;

import org.jose4j.json.internal.json_simple.JSONArray;
import org.jose4j.json.internal.json_simple.JSONObject;
import org.jose4j.json.internal.json_simple.parser.JSONParser;
import org.jose4j.jwk.PublicJsonWebKey;
import org.jose4j.jws.AlgorithmIdentifiers;
import org.jose4j.jws.JsonWebSignature;
import org.jose4j.jwt.JwtClaims;
import org.jose4j.jwt.consumer.JwtConsumer;
import org.jose4j.jwt.consumer.JwtConsumerBuilder;

import oauth.env.EnvVars;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.Base64;

import javax.net.ssl.HttpsURLConnection;

import com.squareup.okhttp.OkHttpClient;

public class JwtUtil {

	public static String createJwt(String issuer, String audience, String subject, String name, String email,
			String cellPhone, int expirationTimeMinutes) throws Exception {
		PublicJsonWebKey jsonWebKey = PublicJsonWebKey.Factory.newPublicJwk(jwkRsaJsonWebKey());

		JwtClaims claims = new JwtClaims();
		claims.setIssuer(issuer); // who creates the token and signs it
		claims.setAudience(audience); // to whom the token is intended to be sent
		claims.setExpirationTimeMinutesInTheFuture(4 * expirationTimeMinutes); // time when the token will expire (10
																				// minutes from now)
		claims.setGeneratedJwtId(); // a unique identifier for the token
		claims.setIssuedAtToNow(); // when the token was issued/created (now)
		claims.setNotBeforeMinutesInThePast(2); // time before which the token is not yet valid (2 minutes ago)
		claims.setSubject(subject); // the subject/principal is whom the token is about
		claims.setClaim("name", name);
		claims.setClaim("email", email);
		claims.setClaim("phone_number", cellPhone);

		JsonWebSignature jws = new JsonWebSignature();
		jws.setPayload(claims.toJson());
		jws.setKey(jsonWebKey.getPrivateKey());
		jws.setKeyIdHeaderValue(jsonWebKey.getKeyId());
		jws.setAlgorithmHeaderValue(AlgorithmIdentifiers.RSA_USING_SHA256);
		return jws.getCompactSerialization(); /** jwt */

	}

	public static JwtClaims consume(String audience, String jwt, String jwkUrl)	throws Exception {
		JwtConsumer jwtConsumer;
		PublicJsonWebKey jsonWebKey = PublicJsonWebKey.Factory.newPublicJwk(getJwkFromUrl(jwkUrl));
		jwtConsumer = new JwtConsumerBuilder().setRequireExpirationTime() // the JWT must have an expiration time
				.setMaxFutureValidityInMinutes(300) // but the expiration time can't be too crazy
				.setAllowedClockSkewInSeconds(30) // allow some leeway in validating time based claims to account
													// for clock skew
				.setExpectedAudience(audience) // to whom the JWT is intended for
				.setVerificationKey(jsonWebKey.getKey()) // verify the signature with the public key
				.build(); // create the JwtConsumer instance
		
		return jwtConsumer.processToClaims(jwt);
	}

	public static String jwkRsaJsonWebKey() {
		return new String(Base64.getDecoder().decode(EnvVars.getJwkRsaWebKey().getBytes()));
	}

	private static String getJwkFromUrl(String jwkUrl) throws Exception {
		OkHttpClient client = new OkHttpClient();
		com.squareup.okhttp.Request request = new com.squareup.okhttp.Request.Builder()
				.url(jwkUrl)
				.get()
				.build();

		String responseBodyString = null;
		try {
			responseBodyString = client.newCall(request).execute().body().string();
		} catch (Exception e) {
			return null;
		}
		
		JSONParser parser = new JSONParser();
		JSONObject tokensJson = (JSONObject) parser.parse(responseBodyString);

		JSONArray keys = (JSONArray) tokensJson.get("keys");

		JSONObject keyJSONObject = (JSONObject) keys.get(0);

		return keyJSONObject.toJSONString();
	}
}