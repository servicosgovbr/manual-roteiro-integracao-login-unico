package oauth.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

public class TokensDto implements Serializable{
	private static final long serialVersionUID = 1L;

	@JsonInclude(Include.NON_EMPTY) public String access_token;
	@JsonInclude(Include.NON_EMPTY) public String token_type;
	@JsonInclude(Include.NON_EMPTY) public Integer expires_in;
	@JsonInclude(Include.NON_EMPTY) public String scope;
	@JsonInclude(Include.NON_EMPTY) public String id_token;
	@JsonInclude(Include.NON_EMPTY) public String refresh_token;
	@JsonInclude(Include.NON_EMPTY) public String status;
	@JsonInclude(Include.NON_EMPTY) public String error_description;

	public TokensDto() {}

	public TokensDto(String access_token, String token_type, Integer expires_in, String scope, String id_token, String refresh_token) {
		super();
		this.access_token = access_token;
		this.token_type = token_type;
		this.expires_in = expires_in;
		this.scope = scope;
		this.id_token = id_token;
		this.refresh_token = refresh_token;
	}

	public TokensDto(String status, String error_description) {
		super();
		this.status = status;
		this.error_description = error_description;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	//"{"error":"invalid_grant","error_description":"JpaAuthorizationCodeRepository: no authorization code found for value oooooooo"}"
}
