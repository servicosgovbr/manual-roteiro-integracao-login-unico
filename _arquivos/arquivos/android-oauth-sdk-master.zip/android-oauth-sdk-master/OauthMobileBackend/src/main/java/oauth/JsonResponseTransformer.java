package oauth;

import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonResponseTransformer {
	private static final ObjectMapper mapper = new ObjectMapper();
	public static String render(Object model) throws Exception {
		return mapper.writeValueAsString(model);
	}
}
