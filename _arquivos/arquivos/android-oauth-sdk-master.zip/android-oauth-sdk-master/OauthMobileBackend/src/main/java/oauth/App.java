package oauth;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import static oauth.env.EnvVars.getIssuer;
import static oauth.env.EnvVars.getClientId;
import static oauth.env.EnvVars.getJwkServiceUrl;

public class App {

	public static final String APP_NAME = "OAUTH_V2";

	private static final int MAIN_SERVER_HTTPPORT = 8081;
	
	private Service service;
	
	private spark.Service mainSrv;

	@SuppressWarnings("unused")
	private View view;
	@SuppressWarnings("unused")
	
	public static void main(String[] args) throws SecurityException, IOException {
		App app = new App();
	}

	public App() {
		try {
			this.service = new Service();
			
			this.mainSrv = spark.Service.ignite().port(MAIN_SERVER_HTTPPORT).threadPool(10);
			this.mainSrv.initExceptionHandler(e -> {
				Logger.getGlobal().log(Level.SEVERE, APP_NAME, e);
				System.exit(100);
			});
			this.mainSrv.before((request, response) -> response.type("application/json"));
			this.mainSrv.defaultResponseTransformer(JsonResponseTransformer::render);

			this.view = new View(getClientId(), getIssuer(), getJwkServiceUrl(), this.service, this.mainSrv);

		} catch (Exception e) {
			Logger.getGlobal().log(Level.SEVERE, APP_NAME, e);
		}
	}
}
