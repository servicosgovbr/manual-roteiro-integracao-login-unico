package oauth.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

public class EmpresasVinculadasDto implements Serializable{
	private static final long serialVersionUID = 1L;

	@JsonInclude(Include.NON_EMPTY) public String cpf;
	@JsonInclude(Include.NON_EMPTY) public List<String> cnpjs;
	
	public EmpresasVinculadasDto() {}

	public EmpresasVinculadasDto(String cpf, List<String> cnpjs) {
		super();
		this.cpf = cpf;
		this.cnpjs = cnpjs;
	}
}
