package oauth;

import java.util.List;

import org.jose4j.jwt.JwtClaims;

import oauth.dto.EmpresaDto;
import oauth.dto.EmpresasVinculadasDto;
import oauth.dto.SelosDto;
import oauth.dto.SessionDto;
import oauth.dto.TokensDto;
import spark.Request;
import spark.Response;

public class View {
	
	private Service service;
	private String clientId;
	private String issuer;
	private String jwkServiceUrl;

	public View(String clientId, String issuer, String jwkServiceUrl, Service service, spark.Service httpServer) {
		this.service = service;
		this.clientId = clientId;
		this.issuer = issuer;
		this.jwkServiceUrl = jwkServiceUrl;
		httpServer.post("/login", this::login);  
	}
		
	public SessionDto login(Request req, Response res) throws Exception{
		String code = req.queryParams("code");
		String codeVerifier = req.queryParams("code_verifier");

		TokensDto tokensDto = service.getTokens(clientId, code, codeVerifier); //Os tokens aqui obtidos (principalmente o access token) não devem ser retornados para o App.

		if (tokensDto.getStatus().equals("FAIL")) {
			return new SessionDto("FAIL");
		}

		//Validação do Access token
		JwtUtil.consume(clientId, tokensDto.access_token, this.jwkServiceUrl);

		//Extração e validação de informações do Id token
		JwtClaims idTokenClaims = JwtUtil.consume(clientId, tokensDto.id_token, this.jwkServiceUrl);

		String cpf = idTokenClaims.getSubject();
		String nome = idTokenClaims.getStringClaimValue("name");
		String email = idTokenClaims.getStringClaimValue("email");
		String telefone = idTokenClaims.getStringClaimValue("phone_number");
		String picuteUrl = idTokenClaims.getStringClaimValue("picture");

		//Verificação de confiabilidade cadastral
		List<SelosDto> selosDto = service.getConfiabilidade(tokensDto.access_token);
		//Caso a sua aplicação só permita o acesso à contas com algum selo de confiabilidade especifico, verificar se tal selo existe no
		//objeto "selosDto". Caso não exista, lançe uma exceção.

		//Acesso ao Serviço de Cadastro de Pessoas Jurídicas
		//Lista de empresas vinculadas ao cpf
		EmpresasVinculadasDto empresasVinculadasDto = service.getEmpresasVinculadas(cpf, tokensDto.access_token);
		//Detalhamento da pessoa jurídica
		String cnpj = "";
		EmpresaDto empresaDto = service.getEmpresaDetalhamento(cpf, cnpj, tokensDto.access_token);
				
		//Recupera fotografia
		String photo = service.getPhoto(picuteUrl, tokensDto.access_token);

		String sessionToken = JwtUtil.createJwt(this.issuer, clientId, cpf, nome, email, telefone, 15);
		
		return new SessionDto(sessionToken, photo);
		
	}
	
}
