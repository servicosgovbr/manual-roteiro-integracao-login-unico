package oauth.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

public class SessionDto implements Serializable{
	private static final long serialVersionUID = 1L;

	@JsonInclude(Include.NON_EMPTY) public String sessionToken;
	@JsonInclude(Include.NON_EMPTY) public String photo;
	@JsonInclude(Include.NON_EMPTY) public String status;

	public SessionDto() {}

	public SessionDto(String sessionToken, String photo) {
		super();
		this.sessionToken = sessionToken;
		this.photo = photo;
	}

	public SessionDto(String status) {
		super();
		this.status = status;
	}
}
