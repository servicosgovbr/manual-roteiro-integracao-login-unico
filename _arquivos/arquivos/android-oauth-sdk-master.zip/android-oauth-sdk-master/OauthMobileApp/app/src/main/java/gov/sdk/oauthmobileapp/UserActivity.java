package gov.sdk.oauthmobileapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.browser.customtabs.CustomTabsIntent;
import androidx.core.graphics.drawable.RoundedBitmapDrawable;
import androidx.core.graphics.drawable.RoundedBitmapDrawableFactory;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

import gov.sdk.oauthmobileapp.oauth.Config;
import gov.sdk.oauthmobileapp.oauth.utilities.SessionStorage;

public class UserActivity extends AppCompatActivity {

    ProgressBar progressBar;
    ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);

        progressBar = (ProgressBar) findViewById(R.id.progressBarUser);

        Button bntLogout = (Button) findViewById(R.id.bntLogout);
        Button bntLogoutAll = (Button) findViewById(R.id.bntLogoutAll);
        TextView txtFieldCpf = (TextView) findViewById(R.id.txtFieldCpf);
        TextView txtFieldName = (TextView) findViewById(R.id.txtFieldName);
        TextView txtFieldPhone = (TextView) findViewById(R.id.txtFieldPhone);
        TextView txtFieldEmail = (TextView) findViewById(R.id.txtFieldEmail);

        imageView = findViewById(R.id.imageView);
        Bitmap batmapBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.default_avatar);
        RoundedBitmapDrawable circularBitmapDrawable = RoundedBitmapDrawableFactory.create(getResources(), batmapBitmap);

        circularBitmapDrawable.setCircular(true);
        imageView.setImageDrawable(circularBitmapDrawable);

        bntLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SessionStorage.clearAll(getBaseContext());
                finishAndRemoveTask();
            }
        });

        bntLogoutAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SessionStorage.clearAll(getBaseContext());
                finishAndRemoveTask();
                String authorizationUrl = Config.LOGOUT_ENDPOINT_URI.getValor() + "?post_logout_redirect_uri=" + Config.REDIRECT_URI.getValor();
                CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
                CustomTabsIntent customTabsIntent = builder.build();
                customTabsIntent.launchUrl(getApplicationContext(), Uri.parse(authorizationUrl));//pass the url you need to open
            }
        });

        //Fetch information from session token
        txtFieldCpf.setText(SessionStorage.getCpf(getBaseContext()));
        txtFieldName.setText(SessionStorage.getName(getBaseContext()));
        txtFieldPhone.setText(SessionStorage.getPhone(getBaseContext()));
        txtFieldEmail.setText(SessionStorage.getEmail(getBaseContext()));

        // display the image data in a ImageView or save it
        if (SessionStorage.getPhoto(getBaseContext()).isEmpty()) {
            return;
        }

        byte [] photob = Base64.decode(SessionStorage.getPhoto(getBaseContext()), Base64.DEFAULT);
        InputStream photois = new ByteArrayInputStream(photob);

        Bitmap bMap = BitmapFactory.decodeStream(photois);

        int height = 400;
        float factor = height / (float) bMap.getHeight();
        batmapBitmap = Bitmap.createScaledBitmap(bMap, (int) (bMap.getWidth() * factor), height, true);

        circularBitmapDrawable = RoundedBitmapDrawableFactory.create(getResources(), batmapBitmap);
        circularBitmapDrawable.setCornerRadius(Math.max(bMap.getWidth(), bMap.getHeight()) / 1.5f);
        imageView.setImageDrawable(circularBitmapDrawable);

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();


    }
}
