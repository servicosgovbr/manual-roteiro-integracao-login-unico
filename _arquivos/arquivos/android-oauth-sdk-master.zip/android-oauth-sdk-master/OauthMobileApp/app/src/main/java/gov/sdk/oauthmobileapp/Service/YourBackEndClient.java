package gov.sdk.oauthmobileapp.Service;

import gov.sdk.oauthmobileapp.oauth.model.SessionDto;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface YourBackEndClient {
    @Headers("Accept: application/json")
    @POST("/login")
    @FormUrlEncoded
    Call<SessionDto> login(@Field("code") String code, @Field("code_verifier") String codeVerifier);

}
