package gov.sdk.oauthmobileapp.oauth;

public enum Config {
    CLIENT_ID("mobile-sdk"),
    REDIRECT_URI("local://oauth2callback"),
    AUTHORIZATION_SCOPE("openid profile phone email govbr_empresa"),
    AUTHORIZATION_ENDPOINT_URI("https://sso.staging.acesso.gov.br/authorize"),
    LOGOUT_ENDPOINT_URI("https://sso.staging.acesso.gov.br/logout"),
    TOKEN_ENDPOINT_URI("http://10.0.2.2:8081/");

    private String valor;

    Config(String valor) {
        this.valor = valor;
    }

    public String getValor() {
        return valor;
    }

    public void setValor(String valor) {
        this.valor = valor;
    }
}
