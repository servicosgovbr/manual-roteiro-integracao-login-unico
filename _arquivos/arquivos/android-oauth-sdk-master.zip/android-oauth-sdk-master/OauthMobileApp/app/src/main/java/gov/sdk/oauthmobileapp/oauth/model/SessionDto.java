package gov.sdk.oauthmobileapp.oauth.model;

import com.google.gson.annotations.SerializedName;

public class SessionDto {

    @SerializedName("sessionToken")
    private String sessionToken;
    @SerializedName("photo")
    private String photo;
    @SerializedName("status")
    private Integer status;

    public String getSessionToken() {
        return sessionToken;
    }

    public String getPhoto() {
        return photo;
    }

    public Integer getStatus() {
        return status;
    }
}
