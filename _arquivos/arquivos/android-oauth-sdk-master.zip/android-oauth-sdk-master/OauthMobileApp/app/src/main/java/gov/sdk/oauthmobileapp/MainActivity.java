package gov.sdk.oauthmobileapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.browser.customtabs.CustomTabsIntent;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.util.UUID;

import gov.sdk.oauthmobileapp.Service.YourBackEndClient;
import gov.sdk.oauthmobileapp.oauth.Config;
import gov.sdk.oauthmobileapp.oauth.model.SessionDto;
import gov.sdk.oauthmobileapp.oauth.utilities.RandomGenerator;
import gov.sdk.oauthmobileapp.oauth.utilities.SessionStorage;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    ProgressBar progressBar;
    Button btnAutorization;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        progressBar.setVisibility(View.INVISIBLE);

        btnAutorization = (Button) findViewById(R.id.bntAutorize) ;

        btnAutorization.setEnabled(true);

        btnAutorization.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nonceValue = UUID.randomUUID().toString();
                String codeVerifier = RandomGenerator.getCodeVerifier();
                String codeChallenge = RandomGenerator.getCodeChallenger(codeVerifier);
                SessionStorage.setCodeVerifier(getBaseContext(), codeVerifier);

                String authorizationUrl = Config.AUTHORIZATION_ENDPOINT_URI.getValor() + "?response_type=code&client_id=" + Config.CLIENT_ID.getValor() + "&scope=" + Config.AUTHORIZATION_SCOPE.getValor().replaceAll(" ", "+") + "&redirect_uri=" + Config.REDIRECT_URI.getValor() +"&nonce=" + nonceValue + "&state=aaaaa&code_challenge_method=S256&code_challenge=" + codeChallenge;
                CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
                CustomTabsIntent customTabsIntent = builder.build();
                customTabsIntent.intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
                customTabsIntent.launchUrl(getBaseContext(), Uri.parse(authorizationUrl));//pass the url you need to open
            }
        });

        if (SessionStorage.getSessionToken(getBaseContext()).isEmpty()) {
            Uri uri = getIntent().getData();

            if (uri != null && uri.toString().startsWith(Config.REDIRECT_URI.getValor())) {
                String code = uri.getQueryParameter("code");

                if (code != null) {
                    fetchSession(code, SessionStorage.getCodeVerifier(getBaseContext()));
                }
            }
        } else
            if (SessionStorage.IsSessionValid(getBaseContext())){
                showUserActivity();
            } else {
                SessionStorage.clearAll(getBaseContext());
                Toast.makeText(MainActivity.this, "Invalid Access Token!", Toast.LENGTH_SHORT).show(); //Not the best practice but it will do for now.
            }

    }

    private void fetchSession(String code, String codeVerifier) {
        Retrofit.Builder builder = new Retrofit.Builder().baseUrl(Config.TOKEN_ENDPOINT_URI.getValor()).addConverterFactory(GsonConverterFactory.create());

        Retrofit retrofit = builder.build();

        YourBackEndClient client = retrofit.create(YourBackEndClient.class);
        Call<SessionDto> callSession = client.login(code, codeVerifier);

        progressBar.setVisibility(View.VISIBLE);
        btnAutorization.setEnabled(false);

        callSession.enqueue(new Callback<SessionDto>() {
            @Override
            public void onResponse(Call<SessionDto> call, Response<SessionDto> response) {
                progressBar.setVisibility(View.INVISIBLE);
                btnAutorization.setEnabled(true);

                SessionDto tokens = response.body();

                if (tokens == null) {
                    Toast.makeText(MainActivity.this, "error : (", Toast.LENGTH_SHORT).show(); //Not the best practice but it will do for now.
                    return;
                }

                //Save tokens
                SessionStorage.setSession(getBaseContext(), tokens);

                //Show User Activity
                showUserActivity();
            }

            @Override
            public void onFailure(Call<SessionDto> call, Throwable t) {
                progressBar.setVisibility(View.INVISIBLE);
                btnAutorization.setEnabled(true);

                Toast.makeText(MainActivity.this, "error : (", Toast.LENGTH_SHORT).show(); //Not the best practice but it will do for now.
            }
        });
    }

    private void showUserActivity() {
        Intent intent = new Intent(this, UserActivity.class);
        startActivity(intent);
    }
}
