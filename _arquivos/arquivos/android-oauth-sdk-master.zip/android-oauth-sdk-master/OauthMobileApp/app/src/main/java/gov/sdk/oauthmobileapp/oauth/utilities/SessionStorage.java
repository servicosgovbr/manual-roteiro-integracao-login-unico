package gov.sdk.oauthmobileapp.oauth.utilities;

import android.content.Context;

import com.auth0.android.jwt.JWT;

import gov.sdk.oauthmobileapp.oauth.model.SessionDto;

import static android.content.Context.MODE_PRIVATE;

public class SessionStorage {

    private static final String CODE_VERIFIER = "CODE_VERIFIER";
    private static final String SESSION_TOKEN = "SESSION_TOKEN";
    private static final String USER_PHOTO = "USER_PHOTO";

    public static void setCodeVerifier(Context context, String codeVerifier) {
        context.getApplicationContext().getSharedPreferences("CODES", MODE_PRIVATE).edit().putString(CODE_VERIFIER, codeVerifier).commit();
    }

    public static String getCodeVerifier(Context context) {
        return context.getApplicationContext().getSharedPreferences("CODES", MODE_PRIVATE).getString(CODE_VERIFIER, "");
    }

    public static void setSession(Context context, SessionDto sessionDto) {
        context.getApplicationContext().getSharedPreferences("SESSION", MODE_PRIVATE).edit().putString(SESSION_TOKEN, sessionDto.getSessionToken()).commit();
        context.getApplicationContext().getSharedPreferences("SESSION", MODE_PRIVATE).edit().putString(USER_PHOTO, sessionDto.getPhoto()).commit();
    }

    public static String getSessionToken(Context context) {
        return context.getApplicationContext().getSharedPreferences("SESSION", MODE_PRIVATE).getString(SESSION_TOKEN, "");
    }

    public static String getPhoto(Context context) {
        return context.getApplicationContext().getSharedPreferences("SESSION", MODE_PRIVATE).getString(USER_PHOTO, "");
    }

    public static Boolean IsSessionValid(Context context) {
        String accessToken = getSessionToken(context);
        if (accessToken.isEmpty()) {
            return false;
        }
        JWT jwt = new JWT(accessToken);
        return !jwt.isExpired(60); //60 seconds leeway
    }

    public static String getCpf(Context context) {
        JWT jwt = new JWT(getSessionToken(context));
        return jwt.getSubject();
    }

    public static String getName(Context context) {
        JWT jwt = new JWT(getSessionToken(context));
        return jwt.getClaim("name").asString();
    }

    public static String getPhone(Context context) {
        JWT jwt = new JWT(getSessionToken(context));
        return jwt.getClaim("phone_number").asString();
    }

    public static String getEmail(Context context) {
        JWT jwt = new JWT(getSessionToken(context));
        return jwt.getClaim("email").asString();
    }

    public static void clearAll(Context context) {
        context.getApplicationContext().getSharedPreferences("SESSION", MODE_PRIVATE).edit().clear().commit();
    }
}
