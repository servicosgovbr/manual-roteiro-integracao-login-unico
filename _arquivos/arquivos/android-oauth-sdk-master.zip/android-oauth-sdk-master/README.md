# EXEMPLO DE IMPLEMENTAÇÃO 

O presente projeto visa demonstrar o processo de integração de um App Android nativo ao GOVBR.

## OBJETIVOS DA APLICAÇÃO

1. Demonstrar através de uma aplicação android nativo como é feita a integração com o GOVBR;
2. Explicar os conceitos da arquitetura OAUTH 2 adotada pelo GOVBR.

## NÃO SÃO OBJETIVOS DA APLICAÇÃO

1. Implementar segurança dos serviços de backend do App;
2. Estabelecer um modelo de UX (User Experience) a ser adotado em um App;

## ARQUITETURA DO GOVBR

O GOVBR usa um padrão aberto de autorização que permite o cidadão fazer logon em sistemas do governo federal usando uma conta de acesso única sem expor suas credenciais. A esse padrão aberto deu-se o nome de OAuth 2.0. Sua especificação e RFCs (Request for Comments) são desenvolvidos e mantidos pelo IETF OAuth WG (https://datatracker.ietf.org/wg/oauth/documents/). 

## ARQUITETURA UTILIZADA DO APP DE EXEMPLO

![](img/arquitetura-mobile.png)

### PASSO 1
O usuário clica no botão "Entre com sua conta GOVBR"

### PASSO 2
O app inicia o processo de autorização chamando o serviço "authorize" por meio do Chrome Custom Tabs (ou do browser padrão) conforme exemplificado no código abaixo. O uso de Webview não é permitido visto que abre a possíbilidade de fishing de credenciais.

```java
public class MainActivity extends AppCompatActivity {
...
@Override
    protected void onCreate(Bundle savedInstanceState) {
        ...
        btnAutorization.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nonceValue = UUID.randomUUID().toString();
                String codeVerifier = RandomGenerator.getCodeVerifier();
                String codeChallenge = RandomGenerator.getCodeChallenger(codeVerifier);
                SessionStorage.setCodeVerifier(getBaseContext(), codeVerifier);

                String authorizationUrl = Config.AUTHORIZATION_ENDPOINT_URI.getValor() + "?response_type=code&client_id=" + Config.CLIENT_ID.getValor() + "&scope=" + Config.AUTHORIZATION_SCOPE.getValor().replaceAll(" ", "+") + "&redirect_uri=" + Config.REDIRECT_URI.getValor() +"&nonce=" + nonceValue + "&code_challenge_method=S256&code_challenge=" + codeChallenge;
                CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
                CustomTabsIntent customTabsIntent = builder.build();
                customTabsIntent.intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
                customTabsIntent.launchUrl(getBaseContext(), Uri.parse(authorizationUrl));
            }
        });
        ...
    }
}
```
1. O AUTHORIZATION_ENDPOINT_URI é a URL do serviço "authorize". Os valores são: "https://sso.staging.acesso.gov.br/authorize" para o ambiente de testes/integração e "https://sso.acesso.gov.br/authorize" para o ambiente de produção;
2. CLIENT_ID é o identificador do sistema cliente do GOVBR. Esse identificador é obtido após o cadastro do sistema;
3. AUTHORIZATION_SCOPE é a relação de informações que o sistema cliente deseja obter do cidadão;
4. REDIRECT_URI é a URI que será chamada no retorno do serviço "authorize". Esta URI deve ser declarada no intent-filter da activity no arquivo AndroidManifest.xml;

### PASSO 3
O usuário entra com suas credenciais (CPF e Senha). Tais credenciais são validadas pelo "Authorization Service" do GOVBR. Caso o usuário entre com as credenciais verdadeiras, o "Authorization Service" retorna para o Chrome Custom Tab (ou para o browser padrão) um código de redirecionamento com a URL informada no parametro "redirect_uri" e um código gerado a partir do parâmetro "nonce". O app verifica se a URL a ser redirecionada consta no "intent-filter" da "activity" do arquivo "AndroidManifest.xml". Em caso positivo, a "activity" correspondente é chamada. Abaixo segue um trecho do arquivo "AndroidManifest.xml".

```xml
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="gov.sdk.oauthmobileapp">
    <!-- The list of permissions -->
    <uses-permission android:name="android.permission.INTERNET" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/AppTheme">
        <activity android:name=".MainActivity" android:noHistory = "true">
        ...
        <intent-filter>
                <action android:name="android.intent.action.VIEW" />
                <category android:name="android.intent.category.DEFAULT" />
                <category android:name="android.intent.category.BROWSABLE" />
                <data android:scheme="local" /> <!-- Neste exemplo toda chamada a uma URL que começa com "local://" chamará esta activity -->
                <!-- No entanto é aconselhável definir, além do "scheme", o "host" e o "path" da URL de retorno conforme o exemplo abaixo:
                    <data android:scheme="coloque-aqui-o-esquema-da-sua-uri-de-retorno" 
                      android:host="coloque-aqui-o-host-da-sua-uri-de-retorno"
                      android:path="coloque-aqui-o-path-da-sua-uri-de-retorno"/>
                    Exemplo: Caso a URL de Retorno seja: "local://exemplo.com/callback", o scheme seria "local", 
                    o host seria "exemplo.com" e o path seria "/callback".
                -->
        </intent-filter>
        ...
        </activity>
        ...
    </application>
    ...
</manifest>
```

### PASSO 4

O app chama sua API de serviços para completar o processo de logon. Este processo só termina quando o Access Token e o Id Token são recuperados e validados com sucesso. Caso ocorra algum erro na recuperação e validação desses tokens, todo o processo de logon deve ser anulado. No caso do nosso App de exemplo, o nosso serviço de backend (chamado "login") chama o serviço de recuperação de token do "Authorization Service" passando os parâmetros "client id", code, code verifier, rediret uri (o mesmo chamado no passo 2) e as credenciais do app conforme os trechos de código abaixo.

Trecho de código do app que chama o serviço "login" do backend (OauthMobileBackend). Cliente HTTP usado: "Retrofit".
```java
public class MainActivity extends AppCompatActivity {
    ...
    private void fetchSession(String code, String codeVerifier) {
        ...
        Retrofit.Builder builder = new Retrofit.Builder().baseUrl(Config.TOKEN_ENDPOINT_URI.getValor()).addConverterFactory(GsonConverterFactory.create());

        Retrofit retrofit = builder.build();

        YourBackEndClient client = retrofit.create(YourBackEndClient.class);
        Call<SessionDto> callSession = client.login(code, codeVerifier);
        ...
        callSession.enqueue(new Callback<SessionDto>() {
            @Override
            public void onResponse(Call<SessionDto> call, Response<SessionDto> response) {
                ...
                SessionDto tokens = response.body();
                ...
                //Save tokens
                SessionStorage.setSession(getBaseContext(), tokens);

                //Show User Activity
                showUserActivity();
            }
            @Override
            public void onFailure(Call<SessionDto> call, Throwable t) {
                ...
            }
        }
    }
}
```

Trecho de código do serviço "login" do backend (OauthMobileBackend). Cliente HTTP usado: OkHTTP.

```java
public class Service {
    ...
    public TokensDto getTokens(String clientId, String code, String codeVerifier) throws IOException {
        OkHttpClient client = new OkHttpClient();
        RequestBody body = RequestBody.create(MediaType.parse("application/json; charset=utf-8"), "{}");
        com.squareup.okhttp.Request request = new com.squareup.okhttp.Request.Builder()
                .url(EnvVars.getTokenServiceUrl() + "?grant_type=authorization_code&client_id=" + clientId +"&code=" + code +"&code_verifier=" + codeVerifier + "&redirect_uri=" + EnvVars.getRedirectUri())
				.post(body)
				.header("Authorization", "Basic " + EnvVars.getCredentials())
				.build();
        com.squareup.okhttp.Response response = client.newCall(request).execute();
        ...
    }
}
```
Obs: A credencial é passada no Authorization header. Ela é uma string composta pela concatenação do client id, ":" e secret . Essa string deve ser codificada em base64 com padding.

#### Validação do id token e do access token
Após obter os tokens, recomendamos a validação de suas assinaturas. Para isso, o gov.br disponibiliza uma chave pública por meio de uma URL. 
O trecho de código abaixo exemplifica essa validação. Neste exemplo foi utilizada a biblioteca "jose4j" mas a sua aplicação pode utilizar qualquer outra biblioteca que realize a mesma operação.

```java
    public class JwtUtil {
        ...
        private static String getJwkFromUrl(String jwkUrl) throws Exception {
		OkHttpClient client = new OkHttpClient();
		com.squareup.okhttp.Request request = new com.squareup.okhttp.Request.Builder()
				.url(jwkUrl)
				.get()
				.build();

		String responseBodyString = null;
		try {
			responseBodyString = client.newCall(request).execute().body().string();
		} catch (Exception e) {
			return null;
		}
		
		JSONParser parser = new JSONParser();
		JSONObject tokensJson = (JSONObject) parser.parse(responseBodyString);

		JSONArray keys = (JSONArray) tokensJson.get("keys");

		JSONObject keyJSONObject = (JSONObject) keys.get(0);

		return keyJSONObject.toJSONString();
	}

        public static JwtClaims consume(String audience, String jwt, String jwkUrl)	throws Exception {
            JwtConsumer jwtConsumer;
            PublicJsonWebKey jsonWebKey = PublicJsonWebKey.Factory.newPublicJwk(getJwkFromUrl(jwkUrl));
            jwtConsumer = new JwtConsumerBuilder().setRequireExpirationTime() // the JWT must have an expiration time
                    .setMaxFutureValidityInMinutes(300) // but the expiration time can't be too crazy
                    .setAllowedClockSkewInSeconds(30) // allow some leeway in validating time based claims to account
                                                        // for clock skew
                    .setExpectedAudience(audience) // to whom the JWT is intended for
                    .setVerificationKey(jsonWebKey.getKey()) // verify the signature with the public key
                    .build(); // create the JwtConsumer instance
            
            return jwtConsumer.processToClaims(jwt);
        }
    }
```

A função **getJwkFromUrl** recupera a chave pública por meio da URL fornecida como parâmetro (**jwkUrl**). 
A função **consume** recupera o Claims do token validando sua assinatura, audience e tempo de expiração. Essa função recebe como parâmetro o "audience" (que é o "clientId" da sua aplicação), o **jwt** (que é o token a ser validado, no caso, o access token e o id token) e o **jwkUrl** (que é a URL do serviço que fornece a chave pública). 

Obs: O parâmetro **jwkUrl** pode assumir os seguintes valores dependendo do ambiente utilizado:

    - Ambiente de testes: https://sso.staging.acesso.gov.br/jwk
    - Ambiente de produção: https://sso.acesso.gov.br/jwk

### PASSO 5 (opcional)
A etapa a seguir verifica a confiabilidade cadastral da conta. Para isso, o backend da sua aplicação deve consultar o serviço de recuperação de selos de confiabilidade cadastral. 
O trecho de código abaixo demonstra como isso pode ser feito.

```java
public class Service {
    ...
    public List<SelosDto> getConfiabilidade(String accessToken) throws Exception {
            ObjectMapper mapper = new ObjectMapper();
            OkHttpClient client = new OkHttpClient();
            com.squareup.okhttp.Request request = new com.squareup.okhttp.Request.Builder()
                    .url(EnvVars.getServiceUrl() + "/api/info/usuario/selo")
                    .get()
                    .header("Authorization", "Bearer " + accessToken)
                    .build();

            String responseBodyString = null;
            try {
                responseBodyString = client.newCall(request).execute().body().string();
                return Arrays.asList(mapper.readValue(responseBodyString, SelosDto[].class));
            } catch (Exception e) {
                return null;
            }
    }
}
```

### PASSO 6 (opcional)
Caso o seu sistema queira verificar quais pessoas jurídicas possuem vinculação ao cpf da conta logada, basta acessar o serviço conforme exemplificado no trecho de código abaixo.

```java
public class Service {
    ...
    public EmpresasVinculadasDto getEmpresasVinculadas(String cpf, String accessToken) throws Exception {
		ObjectMapper mapper = new ObjectMapper();
		OkHttpClient client = new OkHttpClient();
		com.squareup.okhttp.Request request = new com.squareup.okhttp.Request.Builder()
				.url(EnvVars.getServiceUrl() + "/empresas/v1/representantes/" + cpf +"/empresas")
				.get()
				.header("Authorization", "Bearer " + accessToken)
				.build();

		String responseBodyString = null;
		try {
			responseBodyString = client.newCall(request).execute().body().string();
			return mapper.readValue(responseBodyString, EmpresasVinculadasDto.class);
		} catch (Exception e) {
			return null;
		}
	}
}
```
### PASSO 7 (opcional)
Caso o seu sistema queira obter mais informações à respeito da pessoa jurídica vinculada ao cpf da conta logada, basta acessar o serviço conforme exemplificado no trecho de código abaixo.

```java
public class Service {
    ...
    public EmpresaDto getEmpresaDetalhamento(String cpf, String cnpj, String accessToken) throws Exception {
		ObjectMapper mapper = new ObjectMapper();
		OkHttpClient client = new OkHttpClient();
		com.squareup.okhttp.Request request = new com.squareup.okhttp.Request.Builder()
				.url(EnvVars.getServiceUrl() + "/empresas/v1/representantes/" + cpf +"/empresas/" + cnpj)
				.get()
				.header("Authorization", "Bearer " + accessToken)
				.build();

		String responseBodyString = null;
		try {
			responseBodyString = client.newCall(request).execute().body().string();
			return mapper.readValue(responseBodyString, EmpresaDto.class);
		} catch (Exception e) {
			return null;
		}
	}
}
```

### PASSO 8
O access token e o id token recuperados no passo 4 **permanecem no backend e NÃO são repassados ao app**. O id token contém algumas informações básicas do usuário logado como CPF, nome, email, telefone e url do serviço que recupera sua foto (caso exista). No nosso exemplo, o serviço de backend chamado "login" chama o serviço de recuperação da foto e no final cria um token de sessao com as informações extraidas do id token. Esse token de sessão e a foto (caso exista) são as únicas informações que são repassadas ao app.

OBS: É de extrema importância que o access token não seja repassado ao app. Ele deve ficar no serviço de backend (memoria ou banco de dados associados aquela sessão). No caso de nosso exemplo, como toda a operação que necessitava do access token foi feita no próprio serviço de login, não foi necessário armazena-lo.

Trecho de código que recupera a foto do usuário
```java
public class Service {
    ...
    public String getPhoto(String picuteUrl, String accessToken) throws IOException {
        if (picuteUrl == null) {
			return null;
		}
		OkHttpClient client = new OkHttpClient();
		com.squareup.okhttp.Request request = new com.squareup.okhttp.Request.Builder()
				.url(picuteUrl)
				.get()
				.header("Authorization", "Bearer " + accessToken)
				.build();
		com.squareup.okhttp.Response response = client.newCall(request).execute();
		if (response.code() != 200) {
			return null;
		}
		return Base64.getEncoder().encodeToString(IOUtils.toByteArray(response.body().byteStream()));
    }
}
```

Trecho de código que cria o token de sessão do usuário
```java
public class View {
    ...
    public SessionDto login(Request req, Response res) throws Exception{
        ...
        String sessionToken = JwtUtil.createJwt(clientId, cpf, nome, email, telefone, 15);
        ...
    }
}
```

### PASSO 9 (opcional)
De posse do token de sessão, qualquer acesso a uma API do Resource Server do GOVBR, deve ser feita pelo backend do app que recupera o access token (armazenado em memoria ou no banco) e o usa no authorization header.

### PASSO 10
O logout pode ser feito de duas formas:

1. Logout do App. Neste caso, apenas o token de sessão é invalidado. O usuário continua logado no GOVBR. Se ele clicar no botão "Entrar com sua conta GOVBR" não será apresentada a tela de logon e um novo access token, id token e session token será gerado;
2. Logout Geral. Neste caso, não apenas o token de sessão é invalidado, mas o usuário sai do GOVBR.

Trecho de código que implementa o Logout do App. Neste exemplo, o token de sessão é apenas deletado da memória.
```java
public class UserActivity extends AppCompatActivity {
    ...
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ...
        bntLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SessionStorage.clearAll(getBaseContext());
                finishAndRemoveTask();
            }
        });
        ...
    }
    ...
}
```

Trecho de código que implementa o Logout Geral
```java
public class UserActivity extends AppCompatActivity {
    ...
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ...
        bntLogoutAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SessionStorage.clearAll(getBaseContext());
                finishAndRemoveTask();
                String authorizationUrl = Config.LOGOUT_ENDPOINT_URI.getValor() + "?post_logout_redirect_uri=" + Config.REDIRECT_URI.getValor();
                CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
                CustomTabsIntent customTabsIntent = builder.build();
                customTabsIntent.launchUrl(getApplicationContext(), Uri.parse(authorizationUrl));//pass the url you need to open
            }
        });
        ...
    }
    ...
}
```
1. O valor do LOGOUT_ENDPOINT_URI é https://sso.staging.acesso.gov.br/logout para o ambiente de testes/integração e https://sso.acesso.gov.br/logout para o ambiente produtivo.
2. O valor do REDIRECT_URI é a URI para a qual o fluxo será redirecionado após o logout.

## ORIENTAÇÕES PARA EXECUÇÃO DO SERVIÇO DE BACKEND (OauthMobileBackend)

Antes de executar, as seguntes variáveis de ambiente precisam ser criadas:
```bash
export CLIENT_ID="coloque-aqui-o-client-id-da-sua-aplicação"
export TOKEN_SERVICE_URL="https://sso.staging.acesso.gov.br/token"
export REDIRECT_URI="coloque-aqui-o-redirect-uri-identico-ao-informado-no-manifest-do-app-android"
export ISSUER="https://seu-domínio"
export CREDENTIALS="coloque-aqui-as-credenciais-do-sistema-no-formato-indicado-no-passo-4"
export JWK_RSA_WEB_KEY="coloque-aqui-o-par-de-chaves-que-assinarão-o-token-de-sessao"
export JWK_SERVICE_URL="https://sso.staging.acesso.gov.br/jwk"

```

Após a criação das variáveis de ambiente, execute o comando abaixo
```bash
java -agentlib:jdwp=transport=dt_socket,server=y,suspend=n,address=*:8799 -jar oauth-mobile-backend-jar-with-dependencies.jar
```
Onde a porta 8799 será usada para debug. Atenção para a sintaxe "*:" que é usada apartir do java 9. (este exemplo foi testado no java 11)

